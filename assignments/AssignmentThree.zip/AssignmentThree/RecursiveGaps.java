package AssignmentThree;

public class RecursiveGaps {
    public static <E> int numAli(PositionList<E> seq1, PositionList<E> seq2, int maxGaps)
    {
        return numAliHelper(seq1, seq2, 0, 0, 0,  maxGaps);
    }
    public static <E> int totalNumGaps(PositionList<E> seq1, PositionList<E> seq2, int maxGaps)
    {
        return numAliHelper(seq1, seq2, 0, 0, 0,  maxGaps);
    }

    private static <E> int totalNumGapsHelper(PositionList<E> seq1, PositionList<E> seq2, int index1, int index2, int gaps, boolean matchedFirst, int maxGaps)
    {
        if (gaps > maxGaps) return 0;
        if(index1 == seq1.size()) return gaps;
        if(index2 == seq2.size()) return 0;

        int total = 0;

        E elem1 = get(seq1, index1);
        E elem2 = get(seq2, index2);

        if(elem1.equals(elem2))
        {
            total += totalNumGapsHelper(seq1, seq2, index1 + 1, index2 + 1, gaps, true, maxGaps);
        }
        if(!matchedFirst)
        {
            total+= totalNumGapsHelper(seq1, seq2, index1, index2 + 1, gaps, false, maxGaps);
        }
        else{
            total+= totalNumGapsHelper(seq1, seq2, index1, index2 + 1, gaps + 1, true, maxGaps);
        }
        return total;

    }
    private static <E> E get(PositionList<E> list, int index)
    {
        Position<E> p = list.first();
        int index1 = 0;
        while(p != null) {
            if (index1 == index) return p.getElement();
            p = list.after(p);
            index1++;
        }
        throw new IndexOutOfBoundsException("Out of Bounds");
    }

    private static <E> int numAliHelper(PositionList<E> seq1, PositionList<E> seq2, int index1, int index2, int gaps, int maxGaps)
    {

        if (index1 == seq1.size()) return 1;
        if (index2 == seq2.size()) return 0;
        if(gaps >= maxGaps) return 0;  //too many gaps!

        int count = 0;

        //get elements' positions
        E elem1 = get(seq1, index1);
        E elem2 = get(seq2, index2);

        if(elem1.equals(elem2))
        {
            count += numAliHelper(seq1, seq2, index1+1, index2+1, gaps, maxGaps);
        }
        if( index1 > 0)
        {
            count+= numAliHelper(seq1, seq2, index1, index2+1, gaps+1, maxGaps);
        }
        else
        {
            count+= numAliHelper(seq1, seq2, index1, index2+1, gaps, maxGaps);
        }
        return count;
    }


    public static void main(String[] args) {

        DoublyLinkedList<Character> seq1 = new DoublyLinkedList<Character>();
        DoublyLinkedList<Character> seq2 = new DoublyLinkedList<Character>();

        String s1 = "ABBA";
        String s2 = "AABAAABABBABA";
        for (char c : s1.toCharArray()) seq1.addLast(c);
        for (char c : s2.toCharArray()) seq2.addLast(c);

        int maxGaps = 3;
        int totalGaps = totalNumGaps(seq1, seq2, maxGaps);
        int answer = numAli(seq1, seq2, maxGaps);
        System.out.println("Number of alignments (with " + maxGaps + " max gaps): " + answer);
        System.out.println("Total number of gaps: " + totalGaps);


    }
}


