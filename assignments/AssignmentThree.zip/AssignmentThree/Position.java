package AssignmentThree;

public interface Position<E> {
	public abstract E getElement();
}
