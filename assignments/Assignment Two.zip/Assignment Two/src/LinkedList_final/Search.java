package LinkedList_final;

public class Search {
	public static<E> boolean linearSearch(PositionList<E> list, E e) {
		Position<E> current_pos = list.first();
		for(int i=0; i<list.size(); i++){
			if (current_pos.getElement().equals(e)) {
				return true;
			}
			current_pos = list.after(current_pos);
		}
		return false;
	}
	
	public boolean binarySearch(PositionList<Integer> list, int element){
//		assumes list is sorted
		int high = list.size()-1; //largest possible index at which the element can be
		int low = 0;			//lowest possible index at which the element can be
		while (low <= high) {
			int mid = (low + high) / 2;
			int new_element = list.getAtIndex(mid);
			if (element == new_element) return true;
			else if (element < list.getAtIndex(mid)) {high = mid - 1;}
			else {low = mid + 1;}
		}
		return false;
	}
}
