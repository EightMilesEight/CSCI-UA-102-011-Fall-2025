package LinkedList_final;

public class RandomQueue<E> implements PriorityQueue<E>{
	private static class Node<E> {
		E element;
		double priority;
		Node<E> next;
		
		Node(E element, double priority){
			this.element = element;
			this.priority = priority;
			this.next = null;
			
		}
	}
	private Node<E> header;
	private int size;
	private Node<E> trailor;
	
	public RandomQueue()
	{
		header = null;
		size = 0;
	}
	
	public int size()
	{
		return size;
	}
	
	public boolean isEmpty()
	{
		return size == 0;
	}
	
	public void insert(double priority, E element)
	{
		Node<E> newNode = new Node<E>(element, priority);
		if(header == null || priority > header.priority)
		{
			newNode.next = header;
			header = newNode;
		}
		else {
			Node<E> current = header;
			while(current.next != null && current.next.priority >= priority)
			{
				current = current.next;
			}
			newNode.next = current.next;
			current.next = newNode;
		}
		size++;
		
	}
	
	public E removeMaxPriority()
	{
		if(isEmpty()) {
			return null;
		}
		E max = header.element;
		header = header.next;
		size--;
		return max;
	}
	public void insertAtRandom(E element)
	{
		double randomPriority = Math.random();
		insert(randomPriority, element);
	}

	public static void main(String[] args)
	{
		RandomQueue<Integer> randomQueue = new RandomQueue<Integer>();
		Integer[] elements = {1,4,8,7,56,3};
		
		//insert first
		for(Integer element: elements)
		{
			randomQueue.insertAtRandom(element);
		}
		
		while(!randomQueue.isEmpty())
		{
			Integer removed = randomQueue.removeMaxPriority();
			System.out.println(removed);
		}
		
	}
}
