package LinkedList_final;

public class QueuePriority<E> extends PriorityQueueList<E> {
	
	private double count;
	
	void enqueue(E element)
	{
		insert(-count++, element);
	}
	public E dequeue()
	{
		return removeMaxPriority();
	}

}
