package LinkedList_final;
import java.util.*;




public class MyArrayList<E> extends PositionList<E> implements Iterable<E>, Queue<E>{
	
	private static final int MAX_SIZE = 1000;
	private E[] array;
	private int size;
	private double priority;
	private E element;
	

	public MyArrayList(){
		array = (E[ ]) new Object[MAX_SIZE];
		size = 0;
	}
	
	private class ArrayPos implements Position<E>
	{
		private int index;
		
		public ArrayPos(int index)
		{
			this.index = index;
		}
		public E getElement()
		{
			return array[index];
		}
		public int getIndex() { return index;}
	}
	
	

	
	
	public int size() { return size; }
	
	public E getAtIndex(int index) {
		return array[index];
	}
	
	public void addLast(E element) {
		array[size] = element;
		size++;
	}
	
	public E removeLast() {
		E remove = array[size-1];
		array[size-1] = null;
		size--;
		return remove;
	}
	
	public E removeFirst() {
		E remove = array[0];
		for (int i=0; i<size; i++) {
			array[i] = array[i+1];
		}
		size--;
		return remove;
	}
	
	public E removeAtIndex(int i) {
		E remove = array[i];
		for (int j=i; j<size; j++) {
			array[j] = array[j+1];
		}
		size--;
		return remove;
	}

	public void addFirst(E element) {
		for (int i=size; i>0; i--) {
			array[i] = array[i-1];
		}
		array[0] = element;
		size++;
	}
	
	public boolean search(E element){
		for (int i=0; i< size; i++) {
			if (array[i].equals(element)) {
				return true;
			}
		}
		return false;
	}
	
	public Iterator<E> iterator(){
		return new pos_iterator();
	}

	private class pos_iterator implements Iterator<E> {
		private int current = 0;
		
		public boolean hasNext() { return current < size;}
		
		public E next() { return array[current++];}
		
		
	}
		
	
	public Position<E> first()
	{
		return new ArrayPos(0);
	}
	
	public Position<E> last()
	{
		return new ArrayPos(size - 1);
	}
	public Position<E> after(Position<E> p)
	{
		ArrayPos pos = (ArrayPos) p;
		int index = pos.getIndex();
		if(index + 1 >= size) {return null;}
		return new ArrayPos(index +1);
			
	}
	public Position<E> before(Position<E> p)
	{
		ArrayPos pos = (ArrayPos) p;
		int index = pos.getIndex();
		if (index <= 0) {return null;}
		return new ArrayPos(index-1);
	}
	public void addAfter(Position<E> p, E e)
	{
		ArrayPos pos = (ArrayPos) p;
		int index = pos.getIndex();
		for(int i = size; i > index + 1; i--)
		{
			array[i] = array[i - 1];
		}
		array[index+1] = e;
		size++;
	}
	public void addBefore(Position<E> p, E e)
	{
		ArrayPos pos = (ArrayPos) p;
		int index = pos.getIndex();
		for (int i = size; i > index; i--)
		{
			array[i] = array[i-1];
		}
		array[index] = e;
		size++;
	}
	public void set(Position<E> p, E e)
	{
		ArrayPos pos = (ArrayPos) p;
		array[pos.getIndex()] = e;
		
	}
	
	public E remove(Position<E> p)
	{
		ArrayPos pos = (ArrayPos) p;
		return removeAtIndex(pos.getIndex());
	}
	
//	public boolean isEmpty() {
//		return queue.isEmpty();
//	}
//	
//	public void insert(double priority, E element) {
//		
//		Queueing<E> newNode = new Queueing<E>(priority, element);
//		Queue<E> queue;
//		queue.add((E) newNode);
//		
//		
	}
//	E removeMaxPriority() {
//		PositionList<E> queue;
//		if(queue.isEmpty()) {
//			return null;
//		}
//		return queue.remove(0).element;
//		
//	}
//	
	public static void main(String args[])
	{
		
		
		MyArrayList<Integer> list = new MyArrayList<>();
		list.addLast(20);
		list.addLast(30);
		list.addLast(40);
		
		Iterator<Integer> iter = list.iterator();
		while(iter.hasNext()) {
			Integer element = iter.next();
			System.out.println(element);
		}
	}
	
}
