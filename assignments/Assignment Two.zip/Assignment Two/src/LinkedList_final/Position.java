package LinkedList_final;

public interface Position<E> {
	public abstract E getElement();

}
