package LinkedList_final;
import java.util.*;

public class PriorityQueueList<E> implements PriorityQueue<E>, List<E> {
	private ArrayList<Queueing> queue;
	
	
	public class Queueing{
		double priority;
		E element;
	
		public Queueing(double priority, E element) {
	
			this.priority = priority;
			this.element = element;
		}
	}
	
	public  PriorityQueueList() {
		queue = new ArrayList<Queueing>();
	}
	
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return queue.size();
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return queue.isEmpty();
	}

	@Override
	public void insert(double priority, E element) {
		// TODO Auto-generated method stub
		Queueing newElement = new Queueing(priority, element);
		
		//sorting
		int i = 0;
		while(i<queue.size() && queue.get(i).priority <=priority)
		{
			i++;
		}
		queue.add(i, newElement);
		
	}

	@Override
	public E removeMaxPriority() {
		// TODO Auto-generated method stub
		if (queue.isEmpty()) {
			throw new NoSuchElementException("Not in QUEUE");
		}
		return queue.remove(0).element;
	
	}

	public static void main(String[] args)
	{
		PriorityQueueList<Integer> queue = new PriorityQueueList<Integer>();
		
		int[] elements = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		double[] priorities = {3, 4, 2, 7, 6, 8, 5, 9, 1, 0};
		
		for(int i = 0; i < elements.length; i++)
		{
			queue.insert(priorities[i], elements[i]);
		}
		
		System.out.println("Elements removed: ");
		while(!queue.isEmpty())
		{
			System.out.println(queue.removeMaxPriority());
		}
		
	
	}

	@Override
	public void addFirst(E element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addLast(E element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public E removeFirst() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E removeLast() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E getAtIndex(int Index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void add(int i, E element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public E get(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E remove(int i) {
		// TODO Auto-generated method stub
		return null;
	}
}
