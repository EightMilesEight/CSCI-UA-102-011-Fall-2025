package LinkedList_final;

import java.util.Stack;

public class StackPriority<E> extends PriorityQueueList<E>{
	private double count = 0;
	
	public void push(E element)
	{
		count++;
		insert(count, element);
	}
	
	public E pop() {
		return removeMaxPriority();
	}

	
	public static void main(String[] args) {
	    System.out.println("Stack: ");
	    StackPriority<Integer> stack = new StackPriority<Integer>();
	    stack.push(1);
	    stack.push(2);
	    stack.push(3);
	    while (!stack.isEmpty()) {
	        System.out.println(stack.pop()); // Should print: 3, 2, 1
	    }

	    System.out.println("Queue: ");
	    QueuePriority<Integer> queue = new QueuePriority<>();
	    queue.enqueue(1);
	    queue.enqueue(2);
	    queue.enqueue(3);
	    while (!queue.isEmpty()) {
	        System.out.println(queue.dequeue()); // Should print: 1, 2, 3
	    }
	}
}
